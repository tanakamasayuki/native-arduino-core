#include "ArduinoCompat.h"

// instantiate global Serial
SerialClass Serial;
